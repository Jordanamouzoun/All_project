/*
** EPITECH PROJECT, 2024
** CasinoLand
** File description:
** main.c
*/

#include "../include/casino.h"

int main(int argc, char **argv)
{
    menu();
}